# STI Project

## ToDo

1. clean code
2. prepare statement 
3. Comments

## Use case

First, use dock.sh 

Now there are 4 accounts. admin, lio, jere and jee, jee has low rights. The password for each account is the pseudo.

You can try the app    http://localhost:8080